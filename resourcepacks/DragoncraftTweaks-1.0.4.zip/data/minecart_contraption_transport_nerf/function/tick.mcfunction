scoreboard players add timer minecart_contraption_transport_nerf 1
#when the tick counter resets to 1, we scan all 'create:contraptions' that have not been previously scanned
execute if score timer minecart_contraption_transport_nerf matches 1 as @e[type=create:contraption,tag=!minecart_contraption_transport_nerf] run function minecart_contraption_transport_nerf:as_contraption
execute if score timer minecart_contraption_transport_nerf >= timer minecart_contraption_transport_nerf run scoreboard players set timer minecart_contraption_transport_nerf 0