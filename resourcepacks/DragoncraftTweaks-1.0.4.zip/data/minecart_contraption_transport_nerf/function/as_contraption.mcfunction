#we look at all minecarts and modify the data about the passenger, namely we search for any creative blaze burners and then revert them.
##execute as @e[type=minecart] run data remove entity @s Passengers[0].Contraption.Blocks.BlockList[{Data:{isCreative:1b,id:"create:blaze_heater"}}].Data.isCreative
##scrapping this function as it caused immense lag when executed just once on Draconia, which is unnacceptable, will need to code a new method.

##this removes the isCreative:1 from blaze burners on minecart contraptions 
data remove entity @s Contraption.Blocks.BlockList[{Data:{isCreative:1b,id:"create:blaze_heater"}}].Data.isCreative

#this tag is added so the given minecart contraption does not have to be scanned again
tag @s add minecart_contraption_transport_nerf
execute if score dev_mode minecart_contraption_transport_nerf matches 1.. run say I have been scanned and am now clean