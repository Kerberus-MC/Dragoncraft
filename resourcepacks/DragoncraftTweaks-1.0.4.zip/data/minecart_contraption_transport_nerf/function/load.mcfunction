tellraw @a ["",{"text":"["},{"text":"minecart ","color":"red"},{"text":"contraption ","color":"gold"},{"text":" block","color":"yellow"},{"text":" transport","color":"green"},{"text":" nerf","color":"blue"},{"text":"] Loading...","color":"white"}]
scoreboard objectives add minecart_contraption_transport_nerf dummy

execute unless score dev_mode minecart_contraption_transport_nerf = dev_mode minecart_contraption_transport_nerf run scoreboard players set dev_mode minecart_contraption_transport_nerf 0
execute unless score interval minecart_contraption_transport_nerf = interval minecart_contraption_transport_nerf run scoreboard players set interval minecart_contraption_transport_nerf 10



