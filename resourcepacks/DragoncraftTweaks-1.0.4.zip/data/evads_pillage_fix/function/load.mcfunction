tellraw @a ["",{"text":"["},{"text":"Easy ","color":"red"},{"text":"Villagers ","color":"gold"},{"text":"and Dragon","color":"yellow"},{"text":" Survival","color":"green"},{"text":" Pillage fix","color":"blue"},{"text":"] Loading...","color":"white"}]
scoreboard objectives add evads_pillage_fix dummy

#developer mode
execute unless score dev_mode evads_pillage_fix = dev_mode evads_pillage_fix run scoreboard players set dev_mode evads_pillage_fix 0

#how many ticks between scans?
execute unless score interval evads_pillage_fix = interval evads_pillage_fix run scoreboard players set interval evads_pillage_fix 10

#should a new villager be placed, or someone put down an easy villager in the world, what pillage cooldown should they have?
execute unless score cooldown evads_pillage_fix = cooldown evads_pillage_fix run scoreboard players set cooldown evads_pillage_fix 6000



