scoreboard players add timer evads_pillage_fix 1
#when the tick counter resets to 1, we scan all 'minecraft:villager' that have not been previously scanned
execute if score timer evads_pillage_fix matches 1 as @e[type=villager,tag=!evads_pillage_fix] run function evads_pillage_fix:as_villager
execute if score timer evads_pillage_fix >= timer evads_pillage_fix run scoreboard players set timer evads_pillage_fix 0