execute if data entity @s Gossips[{Type:"minor_negative"}] store result entity @s neoforge:attachments.dragonsurvival:entity_handler.pillage_cooldown int 1 run scoreboard players get cooldown evads_pillage_fix

#this tag is added so the given villager does not have to be scanned again
tag @s add evads_pillage_fix
execute if score dev_mode evads_pillage_fix matches 1.. run say I have been scanned and am now clean