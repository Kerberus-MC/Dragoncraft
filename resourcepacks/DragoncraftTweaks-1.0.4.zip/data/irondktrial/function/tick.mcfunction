scoreboard players add irondktrial idkt.scantimer 1
scoreboard players add irondktrial idkt.dedtimer 1
#when timer resets to 1, scan for any not yet tagged
execute if score irondktrial idkt.scantimer matches 1 as @e[type=irons_spellbooks:dead_king_corpse,tag=!dktrial] run function irondktrial:corpse_first_run
execute if score irondktrial idkt.scantimer >= irondktrial idkt.scandelay run scoreboard players set irondktrial idkt.scantimer 0
#when dedtimer reaches 10, kill first-spawn
execute if score irondktrial idkt.dedtimer = irondktrial idkt.deddelay run kill @e[type=irons_spellbooks:dead_king_corpse,tag=ded]
execute if score irondktrial idkt.dedtimer >= 6000 run scoreboard players set irondktrial idkt.dedtimer 11