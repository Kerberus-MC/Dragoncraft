tellraw @a ["",{"text":"["},{"text":"Irons DK Trial Loaded","color":"gold"},{"text":"]"}]
scoreboard objectives add idkt.scandelay dummy
scoreboard objectives add idkt.scantimer dummy
scoreboard objectives add idkt.deddelay dummy
scoreboard objectives add idkt.dedtimer dummy
#ticks between scans
run scoreboard players set irondktrial idkt.scandelay 200
run scoreboard players set irondktrial idkt.deddelay 10