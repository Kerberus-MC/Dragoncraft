scoreboard players operation #CL_TimeC ClearLag = #CL_Time ClearLag
execute unless score #CL_Time ClearLag matches 1 run tellraw @s [{"text":"☽ ","color":"dark_purple"},{"text":"Vaelora","color":"light_purple","bold":true},{"text":" heeds your command and stays her flame...","color":"gray"},{"text":"\n☽ ","color":"dark_purple"},{"text":"The dragon shall rise again in ","color":"gray"},{"score":{"name":"#CL_TimeC","objective":"ClearLag"},"color":"gold"},{"text":" seconds","color":"dark_purple"}]
execute if score #CL_Time ClearLag matches 1 run tellraw @s [{"text":"☽ ","color":"dark_purple"},{"text":"Vaelora","color":"light_purple","bold":true},{"text":" heeds your command and stays her flame...","color":"gray"},{"text":"\n☽ ","color":"dark_purple"},{"text":"The dragon shall rise again in ","color":"gray"},{"score":{"name":"#CL_TimeC","objective":"ClearLag"},"color":"gold"},{"text":" second","color":"dark_purple"}]

##Gamerule rollback##
gamerule sendCommandFeedback false
schedule function clearlag:other/system/gamerule 1t
