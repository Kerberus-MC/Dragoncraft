tellraw @s [{"text":"✦ ","color":"light_purple"},{"text":"Vae's Sanctum","color":"light_purple","bold":true},{"text":" ","color":"dark_purple"},{"text":"(refresh)","color":"gray","clickEvent":{"action":"run_command","value":"/function clearlag:menu"}}]
tellraw @s {"text":"☽ Configure Prophecies","color":"dark_purple","clickEvent":{"action":"run_command","value":"/function clearlag:messages"}}
tellraw @s {"text":"☽ Dragon's Memory","color":"gray","clickEvent":{"action":"run_command","value":"/function clearlag:other/information"}}
tellraw @s {"text":"☽ Ancient Rituals","color":"gold","clickEvent":{"action":"run_command","value":"/function clearlag:other/menu"}}
tellraw @s [{"text":"☽ Cleansing Interval: ","color":"dark_purple"},{"text":"[","color":"gray"},{"score":{"name":"#CL_Time","objective":"ClearLag"},"color":"gold","clickEvent":{"action":"suggest_command","value":"/scoreboard players set #CL_Time ClearLag TIME"},"hoverEvent":{"action":"show_text","value":"In seconds"}},{"text":"] ","color":"gray"},{"text":"(bind)","color":"light_purple","clickEvent":{"action":"run_command","value":"/function clearlag:other/system/apply"}}]

##Gamerule rollback##
gamerule sendCommandFeedback false
schedule function clearlag:other/system/gamerule 1t
