##Messages time before clear##
execute if score #CLM_30_Minutes ClearLag matches 1 if score #CL_TimeC ClearLag matches 1800 run tellraw @a [{"text":"☽ ","color":"dark_purple"},{"text":"Vaelora","color":"light_purple","bold":true},{"text":" stirs in her slumber... The cleansing flame arrives in ","color":"gray"},{"text":"30","color":"gold"},{"text":" minutes","color":"dark_purple"}]
execute if score #CLM_15_Minutes ClearLag matches 1 if score #CL_TimeC ClearLag matches 900 run tellraw @a [{"text":"☽ ","color":"dark_purple"},{"text":"Vaelora","color":"light_purple","bold":true},{"text":" awakens... The realm shall be purified in ","color":"gray"},{"text":"15","color":"gold"},{"text":" minutes","color":"dark_purple"}]
execute if score #CLM_5_Minutes ClearLag matches 1 if score #CL_TimeC ClearLag matches 300 run tellraw @a [{"text":"☽ ","color":"dark_purple"},{"text":"Vae's","color":"light_purple","bold":true},{"text":" eyes glow with ancient power... ","color":"gray"},{"text":"5","color":"yellow"},{"text":" minutes","color":"dark_purple"},{"text":" until the cleanse","color":"gray"}]
execute if score #CLM_1_Minute ClearLag matches 1 if score #CL_TimeC ClearLag matches 60 run tellraw @a [{"text":"☽ ","color":"dark_purple"},{"text":"Vaelora","color":"light_purple","bold":true},{"text":" draws breath... Her dragonfire comes in ","color":"gray"},{"text":"1","color":"gold"},{"text":" minute","color":"dark_purple"}]
execute if score #CLM_30_Secounds ClearLag matches 1 if score #CL_TimeC ClearLag matches 30 run tellraw @a [{"text":"⚠ ","color":"red"},{"text":"Vaelora","color":"light_purple","bold":true},{"text":" spreads her wings! ","color":"gray"},{"text":"30","color":"red","bold":true},{"text":" seconds","color":"dark_red"},{"text":" until dragonfire!","color":"gray"}]
execute if score #CL_TimeC ClearLag matches 0 run function clearlag:clear
execute if score #CL_TimeC ClearLag matches 0 run scoreboard players operation #CL_TimeC ClearLag = #CL_Time ClearLag

execute at @a[scores={ClearLagDeath=1..}] if score #CL_DE ClearLag matches 1 if score #CL_Respawn ClearLag matches 0 run tag @e[type=item,distance=..7] add global.ignore.kill
scoreboard players reset @a[scores={ClearLagDeath=1..}] ClearLagDeath

scoreboard players remove #CL_TimeC ClearLag 1
schedule function clearlag:tick 1s
