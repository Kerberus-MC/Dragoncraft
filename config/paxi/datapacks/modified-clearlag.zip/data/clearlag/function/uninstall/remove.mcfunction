##Message##
tellraw @a [{"text":"[","color":"aqua"},{"text":"ClearLag","color":"green"},{"text":"] "},{"text":"The ","color":"yellow"},{"text":"ClearLag","color":"green"},{"text":" datapack was removed!\nMake sure to remove the datapack folder from the world folder.","color":"yellow"}]

##Scoreboard##
scoreboard objectives remove ClearLag
scoreboard objectives remove ClearLagDeath

##Teams##
team remove CLnocollision
