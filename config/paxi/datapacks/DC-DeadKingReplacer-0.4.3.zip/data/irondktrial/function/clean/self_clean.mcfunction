function irondktrial:clean/update {x:0,z:0}
function irondktrial:clean/update {x:1,z:1}
function irondktrial:clean/update {x:-1,z:-1}
function irondktrial:clean/update {x:1,z:-1}
function irondktrial:clean/update {x:-1,z:1}
function irondktrial:clean/update {x:0,z:1}
function irondktrial:clean/update {x:1,z:0}
function irondktrial:clean/update {x:0,z:-1}
function irondktrial:clean/update {x:-1,z:0}

kill @s[tag=dkded,tag=idkt.cleanup]