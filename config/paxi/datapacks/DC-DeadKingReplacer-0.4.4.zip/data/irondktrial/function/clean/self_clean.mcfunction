function irondktrial:clean/update {x:0,z:0}
function irondktrial:clean/update {x:1,z:1}
function irondktrial:clean/update {x:-1,z:-1}
function irondktrial:clean/update {x:1,z:-1}
function irondktrial:clean/update {x:-1,z:1}
function irondktrial:clean/update {x:0,z:1}
function irondktrial:clean/update {x:1,z:0}
function irondktrial:clean/update {x:0,z:-1}
function irondktrial:clean/update {x:-1,z:0}

kill @e[type=irons_spellbooks:dead_king_corpse,tag=dkded,tag=!idkt.cleanup]
kill @s[tag=dkded,tag=idkt.cleanup]