#places a trial spawner for dead king corpse in the floor in front of the throne
#which will spawn one corpse form of the boss or two active ones if ominous
execute as @s at @s run function irondktrial:spawner/setblock
#tag boss so it isn't repeated.
tag @s add dktrial
execute unless score irondktrial idkt.debug matches 0 run msg @p[tag=idkt.debug] [IDKT.DEBUG] CorpseRun
scoreboard players set irondktrial idkt.dedtimer 0