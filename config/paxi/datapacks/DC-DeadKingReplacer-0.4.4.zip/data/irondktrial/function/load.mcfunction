scoreboard objectives add idkt.scandelay dummy
scoreboard objectives add idkt.scantimer dummy
scoreboard objectives add idkt.deddelay dummy
scoreboard objectives add idkt.dedtimer dummy
scoreboard objectives add idkt.dedmax dummy
scoreboard objectives add idkt.debug dummy
#ticks between scans
execute unless score irondktrial idkt.scandelay matches 200.. run scoreboard players set irondktrial idkt.scandelay 600
execute unless score irondktrial idkt.deddelay matches 10.. run scoreboard players set irondktrial idkt.deddelay 20
#max ded loop
execute unless score irondktrial idkt.dedmax matches 2000.. run scoreboard players set irondktrial idkt.dedmax 6000