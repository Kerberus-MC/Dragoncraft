execute if block ~ ~-1 ~ minecraft:trial_spawner[trial_spawner_state=active] unless block ~ ~-1 ~ minecraft:trial_spawner{registered_players:[[I;0,0,0,0]]} run tag @s add idkt.clean
execute if entity @s[tag=idkt.clean] run data merge block ~ ~-1 ~ {registered_players:[[I;0,0,0,0]]}
kill @s[tag=dkded,tag=idkt.clean]